package de.haw.rn.luca_steven.ui;

public enum Command {
    CONNECT, SEND, DISCONNECT, LIST, EXIT
}
