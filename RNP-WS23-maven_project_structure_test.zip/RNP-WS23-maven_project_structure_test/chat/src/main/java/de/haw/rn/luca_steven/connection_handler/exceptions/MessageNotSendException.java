package de.haw.rn.luca_steven.connection_handler.exceptions;

public class MessageNotSendException extends Exception {
    public MessageNotSendException(String message) {
        super(message);
    }
}
